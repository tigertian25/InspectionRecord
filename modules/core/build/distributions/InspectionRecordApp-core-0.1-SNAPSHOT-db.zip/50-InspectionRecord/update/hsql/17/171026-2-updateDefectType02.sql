alter table INSPECTIONRECORD_DEFECT_TYPE alter column CAUSE_JOB_ID set null ;
